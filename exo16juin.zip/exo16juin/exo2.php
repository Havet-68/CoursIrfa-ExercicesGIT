<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Exo 2</title>
</head>
<body>
	<?php 

	echo phpversion(). " "; // 7.3.12
	echo PHP_OS; // WINNT

	?>

</body>
</html>