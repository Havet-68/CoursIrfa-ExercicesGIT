<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Exo 1</title>
</head>
<body>
	<?php

	// var="0"; Pas ok
	$mvar="1"; //ok
	$var7="2"; //ok
	$_mvar="3"; //ok
	$_6var="4"; //ok
	$_élément1="5"; //ok
	$hotel14="6"; // ok

	echo $mvar . " " . $var7 . " " . $_mvar . " " . $_6var . " " . $_élément1 . " " . $hotel14;

	//Sur les 7 exemples, 6 sont donc valides.

	?>



</body>
</html>