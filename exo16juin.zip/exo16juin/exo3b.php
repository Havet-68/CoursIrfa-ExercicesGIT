<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title> Exo3 Partie B</title>
</head>
<body>
	<h1>Titre principal</h1>

	<?php 

	  $x = 10;    
            echo 'La valeur de $x globale est : ',  $x, '<br>';
            $x = 15;
            echo '$x contient maintenant : ', $x, '<br>';
            echo '<p>Un paragraphe</p>';

	?>

</body>
</html>