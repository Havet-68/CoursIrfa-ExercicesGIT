<!DOCTYPE html>
<html>
<head>
	<title>Exo3 Partie A</title>
</head>
<body>

   <H1>Titre principal</H1>

	<?php 


          $x = null;     
          echo 'La valeur de $x globale est :',  $x, '<br>';     
          echo 'La valeur de $x locale est : ', $x = 5, '<br>';     
          $y = 1;     
          echo '$y contient la valeur: ', $y, '<br>';     
          echo '$y contient la valeur: ', $y, '<br>'; 
          function(){
              $z = null;
            };     
          echo 'La variable locale $z contient : '; 
          echo '<p>Un paragraphe</p>'

	?>

</body>
</html>