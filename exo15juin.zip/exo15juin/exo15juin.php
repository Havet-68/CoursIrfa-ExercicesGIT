<!DOCTYPE html>
<html>
<head>
<title><?php Bonjour en php ?></title>
</head>
<body>

<?php
echo "bonjour généré dynamiquement en php !";
?>

</body>
</html> 