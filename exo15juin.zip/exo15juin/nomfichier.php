<!DOCTYPE html>
<html>
<head>
<title><?php echo "Quel jour sommes nous"; ?></title>;
</head>
<body>



<?php
$date = date("d-m-Y");
$heure = date("H:i");
print("Hello PHP nous sommes le $date et il est $heure. ");

if (date('H') >= 06 AND date('H') < 12){
	echo "Bon matin !";
}elseif (date('H') >= 12 AND date('H') < 18){
	echo "Bonne après-midi !";
}
?>

</body>
</html> 